#include <iostream>
#include <fstream>                                                   // Deklarowanie potrzebnych bibliotek.
#include <time.h>
#include <iomanip>
#include <stdlib.h>

using namespace std;
const int N=10000;                                                    // Deklarowanie stalej N i stalej K typu intiger.
const int K=40;
double czas;
clock_t start,stop;

void zapis_do_pliku()
{
    fstream plik;                                                     // Deklarowanie zmiennej typu fstream ma na celu otworzenie
    plik.open("plik_wejsciowy.txt", ios::out);                        // pliku tekstowego.( Jeœli nie istnial wczesniej, zostanie utworzony teraz)

    srand((unsigned)time(NULL));                                      // Funkcja zapis_do_pliku() losuje K wartoœæi z przedzia³u od 0 do N
                                                                      // i zapisuje je w otworzonym pliku
    for(int i = 0; i < K; i++)
    {
        int j=rand()%N;
        plik<<j<< endl;
    }

    plik.close();                                                     // Zamykanie pliku
}
void wczytanie_danych(int tab[])
{
    cout<<"Wylosowana tablica to: "<<endl<<endl;                     // Funkcja wczytanie_danych ma za zadanie wczytywanie danych
    fstream plik1;                                                    // z pliku tekstowego i wpisywanie ich do tablicy
    plik1.open( "plik_wejsciowy.txt", ios::in);
    string linia;
    int i =0;
    cout<<"[";
    while(getline(plik1,linia))
    {
        tab[i]=atoi(linia.c_str());                                    // Konwertowanie danych z typu string na typ intiger
        cout<<tab[i]<<setw(6);
        i++;
    }
    cout<<"]";
}
void sortowanie_przez_wstawianie(int d[])
{                                                                      // Funkcja sortowanie_przez_wstawianie() ma za zadanie sortowaæ
    fstream plik2;                                                     // elementy wpisane do tablicy w funkcji wczytywanie_danych().
    plik2.open( "plik_wyjsciowy.txt", ios::out);                       // Sortowanie odbywa siê za pomoc¹ wstawiania.
    int j,i,x;                                                         // W tej funkcji otwieramy nowy plik tekstowy na takiej samej zasadzie
    for(j = K - 2; j >= 0; j--)                                        // jak post¹piliœmy z z poprzednio otworzonym plikiem.(Jeœli plik do tej
    {                                                                  // pory nie istnial zostanie utworzony teraz.
        x = d[j];
        i = j + 1;
        while((i < K) && (x > d[i]))
        {
            d[i - 1] = d[i];
            i++;
        }
        d[i - 1] = x;
    }

   plik2 << "Po sortowaniu przez wstawianie: "<<endl<<endl;            // Posortowane elementy
   plik2<<"[";
    for(i = 0; i < K; i++)
    {
       plik2 << setw(6) << d[i];
    }
   plik2<<"]";
    plik2.close();                                                     // Zamykanie pliku
}
void sortwanie_przez_zliczanie(int tab[])
{                                                                      // Funkcja sortwanie_przez_zliczanie() ma za zadanie sortowac
    fstream plik2;                                                     // elementy wpisane do tablicy w funkcji wczytywanie_danych().
    plik2.open( "plik_wyjsciowy.txt", ios::out);                       // W tej funckji otwieramy ten sam plik co przy wyborze
    plik2<<"Po sortowaniu przez zliczanie: "<<endl;                    // sortowania przez wstawianie.
    int t[N];

    for(int i=0;i<N;i++)                                               // Sortowanie odbywa siê za pomoca zliczania.
        t[i]=0;

    for(int j=0;j<N+1;j++)
        for(int i=0;i<K;i++)
            if(j==tab[i])
                t[tab[i]]+=1;

   plik2<<endl<<"[ ";
    for(int i=0;i<N;i++)
        for(int j=0;j<t[i];j++)
           plik2<<i<<setw(6);
   plik2<<"]";
    plik2.close();                                                     // Zamykanie pliku.
}
void wybieranie(int tab[])
{
    cout<<endl<<endl;
    cout<<"Wybierz metode sortowania :"<<endl<<"1. Sortowanie przez wstawianie."<<endl<<"2. Sortowanie przez zliczanie."<<endl;
    int wybor;
    cin>>wybor;
     switch(wybor)                                                                         // Funkcja wybieranie() to menu programu. U¿ytkownik po
    {                                                                                      // uruchomieniu programu ma do wyboru dwa sortowania.
        case 1:                                                                            // Wyboru dokonuje siê poprez wpisanie numeru 1 lub 2.
            start=clock();
            sortowanie_przez_wstawianie(tab);
            stop=clock();
            cout<<"Wyniki zostaly umieszczone w pliku tekstowym."<<endl;
            czas=(double)(stop-start)/CLOCKS_PER_SEC;
            cout<<"Czas sortowania przez wstawianie wynosi: "<<czas<<endl;                 // Funkcja clock() ma za zadanie podawanie czasu działania
            break;                                                                         // wybranego sortowania.
        case 2:
            start=clock();
            sortwanie_przez_zliczanie(tab);
            stop=clock();
            cout<<"Wyniki zostaly umieszczone w pliku tekstowym."<<endl;
            czas=(double)(stop-start)/CLOCKS_PER_SEC;
            cout<<"Czas sortowania przez zliczanie wynosi: "<<czas<<endl;
            break;
        default:system("CLS");                                                             // Po wybraniu nieprawidlowego numeru na ekranie pojawi sie komunikat
            cout<<"Wybrano nieprawidlowa opcje!"<<endl<<"Wybierz poprawnie."<<endl<<endl;  // z linijki nr. 117. Użytkownik bedzie mial mozliwosc ponownego
        wczytanie_danych(tab);                                                             // wyboru.
        wybieranie(tab);
    }
}

int main()
{
                                                                                          // Glowna funkcja main() ma za zadanie wywolywanie poszczegolnych
    int tab[K];                                                                           // funckji w odpowiedniej kolejnosci by program mogl dzialac
    zapis_do_pliku();                                                                     // prawidlowo.
    wczytanie_danych(tab);
    //badanie_zlozonosci_czasowej_dla_przypadkow(tab);
    wybieranie(tab);
    return 0;
}

////////////////////////////////////////////////////////////////////////////////////////
/*
 BADANIE ZLOZONOSCI CZASOWEJ DLA PRZYPADKOW:
- OCZEKOWANY,
- PESYMISTYCZNY,
- OPTYMISTYCZNY.

//DLA OPTYMISTYCZNEGO SCENARIUSZA

void badanie_zlozonosci_czasowej_dla_przypadkow(int tablica[])
{
    int i;
    cout<<" Badanie zlozonosci czasowych w 3 przypadkach"<<endl;
    for(i=0;i<K;i++)
    {
        tablica[i]=i;
        cout<<tablica[i]<<setw(8);
    }
}

//DLA PESYMISTYCZNEGO SCENARIUSZA

void badanie_zlozonosci_czasowej_dla_przypadkow(int tablica[])
{
    int i,j=K-1;
    cout<<" Badanie zlozonosci czasowych w 3 przypadkach"<<endl;
    for(i=0;i<K;i++)
    {
        tablica[j]=i;
        j--;
    }
    for(i=0;i<K;i++)
        cout<<tablica[i]<<setw(8);
}

//SCENARIUSZ OCZEKIWANY TO SCENIARIUSZ ZWYKLY USTALONY W PROGRAMIE

*/



